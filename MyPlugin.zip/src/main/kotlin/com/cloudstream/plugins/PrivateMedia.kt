package com.cloudstream.plugins

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*

class PrivateMedia : MainAPI() {
    override var mainUrl = "https://www.erome.com/"
    override var name = "PrivateMedia"
    override val hasMainPage = true
    override val supportedTypes = setOf(TvType.Movie)

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val items = listOf(
            newMovieSearchResponse("Sample Album", "https://www.erome.com/a/azA0VkUR", TvType.Movie) {
                this.posterUrl = null
            }
        )
        return HomePageResponse(listOf(HomePageList("Albums", items)))
    }

    override suspend fun load(url: String): LoadResponse {
        val doc = app.get(url).document
        val videoUrl = doc.select("video source").attr("src")

        return newMovieLoadResponse("Sample Video", url, TvType.Movie, videoUrl) {
            this.posterUrl = null
        }
    }
}