plugin {
    id = "private.media.album"
    name = "PrivateMedia"
    version = "1.0.0"
    author = "ChatGPT"
}